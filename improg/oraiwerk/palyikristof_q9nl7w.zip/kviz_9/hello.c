#include <stdio.h>
#include "hello.h"

void printHelloWorld()
{
    printf("Hello World!\n");
}