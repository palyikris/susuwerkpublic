#include "hello.h"

int main()
{
    // Call the function from the hello.c file
    printHelloWorld();

    return 0;
}